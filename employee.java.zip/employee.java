public class employee{
    private String name;
    private String surname;
    private double salary;
    public employee(String name,String surname,double salary){
        this.name=name;
        this.surname=surname;
        this.salary=salary;
        
    }
    public void set_name(String name){
        this.name=name;
    }
    public String get_name(){
        return name;
    }
    public void set_surname(String surname){
        this.surname=surname;
    }
    public String get_surname(){
        return surname;
    }
    public void set_salary(double salary){
        this.salary=salary;
    }
    public void get_salary_increase(double salary){
        salary=salary+salary*10/100;
        
    }

    public double get_salary(){
        return salary;
    }
}