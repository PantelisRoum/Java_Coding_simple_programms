// this is the main programm 
public class Main{
    public static void main(String[] args){
        employee empl_1=new employee("Pantelis","Roumelis",100000.00);
        employee empl_2=new employee("Giannis","Roumelis",2000.00);
        System.out.printf("Employee name:%s\nEmployee surname:%s\nSalary:%.2f",empl_1.get_name(),empl_1.get_surname(),empl_1.get_salary());
        System.out.printf("\nEmployee name:%s\nEmployee surname:%s\nSalary:%.2f",empl_2.get_name(),empl_2.get_surname(),empl_2.get_salary());
        System.out.println("\nWe are increasing the salary of the 2 Employees by 10/100");
        empl_1.get_salary_increase(empl_1.get_salary());
        empl_2.get_salary_increase(empl_2.get_salary());
        System.out.printf("\nEmployee 1 salary:%.2f",empl_1.get_salary());
        System.out.printf("\nEmployee 2 salary:%.2f",empl_2.get_salary());
    } 
    
    
}
